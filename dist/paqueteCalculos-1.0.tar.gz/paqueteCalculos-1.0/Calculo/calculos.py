def sumar(op1, op2):
    print("El resultado de la suma es: " , op1 + op2)
def restar(op1, op2):
    print("El resultado de la suma es: ", op1 - op2)

def multiplicar(op1, op2):
    print("La multiplicacion es: ", op1 *op2)

def potencia(base, exponente):
    #los dobles arteriscos calculan la potencia
    print("El resultado de la potencia es: ", base**exponente)

def redondear(numero):
    print("El resultado del redondeo es: ", round(numero))
