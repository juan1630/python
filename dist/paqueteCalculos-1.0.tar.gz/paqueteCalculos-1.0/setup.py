from setuptools import setup

setup(
    name="paqueteCalculos",
    version="1.0",
    description="Paquete de  redondeo y potencia",
    author="Juan",
    author_email="josejuanpatron1630@gmail.com",
    packages=["Calculo","Calculo.redondeo_pot"]
)
